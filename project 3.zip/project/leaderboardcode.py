def leaderboard():
    import pygame,sys,mysql.connector, random

    #initial setup
    pygame.init()
    screen=pygame.display.set_mode((800,600))
    pygame.display.set_caption('Leaderboard')
    crown=pygame.image.load("crown.png")
    pygame.display.set_icon(crown)
    clock=pygame.time.Clock()
    pygame.mixer.music.load('leaderboard.wav')
    pygame.mixer.music.play(-1)
    textfont=pygame.font.Font('alagard.ttf',48)
    background=pygame.image.load("leaderboard.png")
    a=255
    b=255
    c=255
    p=0.25
    #sql connectivity

    con=mysql.connector.connect(host='localhost',user='root',passwd='sohamkukreti',database='arcade')
    cur=con.cursor()
    arrowlist=[]
    ponglist=[]
    escapelist=[]
    snakelist=[]
    spacelist=[]
    cur.execute('select * from arrow;')
    for x in cur:
        arrowlist.append(x)
    cur.execute('select * from escape;')
    for x in cur:
        escapelist.append(x)
    cur.execute('select * from pong;')
    for x in cur:
        ponglist.append(x)
    cur.execute('select * from pong;')
    for x in cur:
        ponglist.append(x)
    cur.execute('select * from snake;')
    for x in cur:
        snakelist.append(x)
    cur.execute('select * from space;')
    for x in cur:
        spacelist.append(x)
    #print(arrowlist,ponglist,escapelist,sep='\n')

    pong_maxuser=''
    pong_maxscore=0
    arrow_maxuser=''
    arrow_maxscore=0
    escape_maxuser=''
    escape_maxscore=0
    snake_maxuser=''
    snake_maxscore=0
    space_maxuser=''
    space_maxscore=0
    for x in arrowlist:
        if x[1]>arrow_maxscore:
            arrow_maxscore=x[1]
            arrow_maxuser=x[0]
    for x in escapelist:
        if x[1]>escape_maxscore:
            escape_maxscore=x[1]
            escape_maxuser=x[0]
    for x in ponglist:
        if x[1]>pong_maxscore:
            pong_maxscore=x[1]
            pong_maxuser=x[0]
    for x in snakelist:
        if x[1]>snake_maxscore:
            snake_maxscore=x[1]
            snake_maxuser=x[0]
    for x in spacelist:
        if x[1]>space_maxscore:
            space_maxscore=x[1]
            space_maxuser=x[0]
    #print(arrow_maxuser, pong_maxuser, escape_maxuser)

    running=True
    while running:
        screen.blit(background,(0,0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running=False
                    pygame.mixer.music.load("arcadebackground.wav")
                    pygame.mixer.music.play(-1)
        a-=1*p
        b-=3*p
        c-=3*p
        L=[a,b,c]
        if min(L)<=180:
            p=-0.25
        if max(L)>=255:
            p=0.25
        arrowtext=textfont.render(arrow_maxuser+" : "+str(arrow_maxscore),True,(a,b,c))
        escapetext=textfont.render(escape_maxuser+" : "+str(escape_maxscore), True,(a,b,c))
        pongtext=textfont.render(pong_maxuser+" : "+str(pong_maxscore), True,(a,b,c))
        snaketext=textfont.render(snake_maxuser+" : "+str(snake_maxscore), True,(a,b,c))
        spacetext=textfont.render(space_maxuser+" : "+str(space_maxscore), True,(a,b,c))
        screen.blit(arrowtext,(500,100))
        screen.blit(escapetext,(500,200))
        screen.blit(pongtext,(500,300))
        screen.blit(snaketext,(500,400))
        screen.blit(spacetext,(500,500))
        
        clock.tick(60)
        pygame.display.update()
