def escape():
    import pygame,sys
    import random
    from pygame import mixer
    #initialising and setup
    pygame.init()
    screen=pygame.display.set_mode((800,600))
    pygame.display.set_caption("Escape!")
    icon=pygame.image.load("escape.png")
    background=pygame.image.load("background.jpg")
    textfont=pygame.font.Font("freesansbold.ttf",48)
    pygame.display.set_icon(icon)
    score=0
    mixer.music.load("escapebmg.wav")
    mixer.music.play(-1)
    gameover=pygame.image.load('gameover1.png')
    gamestate=''
    userinfo=''

    '''
    con=mysql.connector.connect(host='localhost',user='root',passwd='sohamkukreti',database='arcade')
    cur=con.cursor()    
    '''
    
    #text
    def text():
        text=textfont.render("Score : "+str(score),True,(23,23,23))
        screen.blit(text,(400,300))

    #floors
    randomise=random.randint(0,500)
    randomise2=random.randint(0,500)
    randomise3=random.randint(0,500)
    randomise4=random.randint(0,500)
    global ballX,ballY
    ballX=380
    ballY=80

    ball=pygame.Rect(ballX,ballY,20,20)

    rectanglefinal=pygame.Rect(0,0,800,10)

    floor1pos=500
    floor2pos=650
    floor3pos=800
    floor4pos=950
    speed=-0.05
    ballspeed=0.5
    ballXspeed=0
    ballX=380
    ballY=80
    number=0

           

    running=True
    while running:
        screen.blit(background,(0,0))
        pygame.draw.rect(screen,(255,0,0),rectanglefinal)
        text()

        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_LEFT:
                    ballXspeed-=0.5
                if event.key==pygame.K_RIGHT:
                    ballXspeed+=0.5
            if event.type==pygame.KEYUP:
                if event.key==pygame.K_LEFT:
                    ballXspeed+=0.5
                if event.key==pygame.K_RIGHT:
                    ballXspeed-=0.5
                if event.key==pygame.K_ESCAPE:
                    running=False
                    mixer.music.load("arcadebackground.wav")
                    mixer.music.play(-1)
                if event.key==pygame.K_RETURN:
                    if gamestate=='over':
                        '''
                        cur.execute("insert into escape values('{}',{})".format(userinfo,score))
                        con.commit()
                        '''
                        print(userinfo,score)
                        gamestate='playing'
                        print("inserted values into the database")
                        score=0
                        speed=-0.05
                        ballX=380
                        ballY=80
                        floor1pos=500
                        floor2pos=650
                        floor3pos=800
                        floor4pos=950
                if gamestate=='over':
                    userinfo+=event.unicode
                    if event.key==pygame.K_BACKSPACE:
                        userinfo=userinfo[0:-2]                    
        number=number+1
        if number%500==0:
            score+=1
        
        
        floor1pos+=speed
        floor2pos+=speed
        floor3pos+=speed
        floor4pos+=speed



        
        if floor1pos<=0:
            floor1pos=600
            randomise=random.randint(0,500)



        if floor2pos<=0:
            floor2pos=600
            randomise2=random.randint(0,500)
        if floor3pos<=0:
            floor3pos=600
            randomise3=random.randint(0,500)
        if floor4pos<=0:
            floor4pos=600
            randomise4=random.randint(0,500)

        ballY+=ballspeed
        #global ballY,ballX,rectanglefinal,floor1pos,floor2pos,floor3pos,floor4pos
        ball=pygame.Rect(ballX,ballY,20,20)
        pygame.draw.ellipse(screen,(235,35,35),ball)
        rectangle1_1=pygame.Rect(0,floor1pos,100+randomise,10)
        rectangle1_2=pygame.Rect(180+randomise,floor1pos,4000,10)
        rectangle2_1=pygame.Rect(0 ,floor2pos,100 + randomise2,10)
        rectangle2_2=pygame.Rect(180 + randomise2,floor2pos,4000,10)
        rectangle3_1=pygame.Rect(0 ,floor3pos,100 + randomise3,10)
        rectangle3_2=pygame.Rect(180 + randomise3,floor3pos,4000,10)
        rectangle4_1=pygame.Rect(0,floor4pos,100 + randomise4,10)
        rectangle4_2=pygame.Rect(180+randomise4,floor4pos,4000,10)
        pygame.draw.rect(screen,(255,255,255),rectangle1_1)
        pygame.draw.rect(screen,(255,255,255),rectangle1_2)
        pygame.draw.rect(screen,(255,255,255),rectangle2_1)
        pygame.draw.rect(screen,(255,255,255),rectangle2_2)
        pygame.draw.rect(screen,(255,255,255),rectangle3_1)
        pygame.draw.rect(screen,(255,255,255),rectangle3_2)
        pygame.draw.rect(screen,(255,255,255),rectangle4_1)
        pygame.draw.rect(screen,(255,255,255),rectangle4_2)


        if ball.colliderect(rectangle1_1) or ball.colliderect(rectangle1_2):
            ballY=floor1pos-20
        if ball.colliderect(rectangle2_1) or ball.colliderect(rectangle2_2):
            ballY=floor2pos-20
        if ball.colliderect(rectangle3_1) or ball.colliderect(rectangle3_2):
            ballY=floor3pos-20
        if ball.colliderect(rectangle4_1) or ball.colliderect(rectangle4_2):
            ballY=floor4pos-20


        if ball.left<=0:
            ballX=1
        if ball.right>=800:
            ballX=780
        if ballY>=580:
            ballY=580
        ballX+=ballXspeed
        if ball.colliderect(rectanglefinal):
            floor1pos=500
            floor2pos=650
            floor3pos=800
            floor4pos=950
            speed=(-0.05)
            ballX=380
            ballY=80
            score=0
        if ballY<=10:
            gamestate='over'
                    
        speed-=0.00001
        usertext=textfont.render(f"{userinfo}",False,(255,255,0))
        if gamestate=='over':
            speed=0
            screen.blit(gameover,(0,0))
            screen.blit(usertext,(250,350))
            
        pygame.display.update()

