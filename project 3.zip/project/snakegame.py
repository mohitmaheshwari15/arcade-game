def snake():
    import pygame, sys, time, random
    from pygame import mixer
    #import mysql.connector

    frame_size_x = 800
    frame_size_y = 600
    
    #initialising pygame
    pygame.init()
    pygame.display.set_caption('Snake')
    screen = pygame.display.set_mode((frame_size_x, frame_size_y))
    '''
    mydb = mysql.connector.connect(host= 'localhost', user = 'root', passwd = 'sohamkukreti', database = 'arcade')
    mycursor = mydb.cursor()
    '''
    gameoverimg=pygame.image.load('gameover1.png')
    icon = pygame.image.load('snake-2.png')
    grass = pygame.image.load('grass.png')
    mixer.music.load("bgm.mp3")
    fps_controller = pygame.time.Clock()
    base_font = pygame.font.Font('freesansbold.ttf', 60)
    mixer.music.set_volume(0.3)
    mixer.music.play(-1)
    sound = pygame.mixer.Sound('Minecraft Eating - Sound Effect (HD).mp3')
    burge = pygame.image.load('hamburger.png')
    DEFAULT_IMAGE_SIZE = (25,25)
    burger1 = pygame.transform.scale(burge, DEFAULT_IMAGE_SIZE)
    
    #assigning colors to variables
    black = pygame.Color(0, 0, 0)
    white = pygame.Color(255, 255, 255)
    red = pygame.Color(255, 0, 0)
    green = pygame.Color(0, 255, 0)
    blue = pygame.Color(0, 0, 255)

    #setting up game variables
    life = 1
    userinfo = ''
    score = 0 
    snake_pos = [100, 50]
    snake_body = [[100, 50], [100-25, 40], [100-(2*25), 50]]
    food_pos = [random.randrange(1, (frame_size_x//25)) * 25, random.randrange(1, (frame_size_y//25)) * 25]
    food_spawn = True
    direction = 'RIGHT'
    change_to = direction
    snake_speed = 25



    # score
    def show_score(choice, color, size):
        score_font = pygame.font.Font('freesansbold.ttf', size)
        score_surface = score_font.render('Score : ' + str(score), True, color)
        score_rect = score_surface.get_rect()
        if choice == 1:
            score_rect.midtop = (frame_size_x/10, 15)
        else:
            score_rect.midtop = (frame_size_x/2, frame_size_y/1.25)
        screen.blit(score_surface, score_rect)



    #game loop
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    change_to = 'UP'
                if event.key == pygame.K_DOWN:
                    change_to = 'DOWN'
                if event.key == pygame.K_LEFT:
                    change_to = 'LEFT'
                if event.key == pygame.K_RIGHT:
                    change_to = 'RIGHT'
                if event.key == pygame.K_ESCAPE:
                    running=False
                    mixer.music.load("arcadebackground.wav")
                    mixer.music.play(-1)
                if event.key==pygame.K_RETURN:
                        if life==0:
                            '''
                            mycursor.execute('insert into snake values("{}", {})'.format(userinfo,score))
                            mydb.commit()
                            '''
                            print(userinfo,score)
                            life = 1
                            print("Values inserted")
                            score = 0
                            running = False
                            mixer.music.load("arcadebackground.wav")
                            mixer.music.play(-1)
                if life == 0:
                    userinfo += event.unicode
                    if event.key == pygame.K_BACKSPACE:
                        userinfo = userinfo[0:-2]
                            

        # Making sure the snake cannot move in the opposite direction immediately
        if change_to == 'UP' and direction != 'DOWN':
            direction = 'UP'
        if change_to == 'DOWN' and direction != 'UP':
            direction = 'DOWN'
        if change_to == 'LEFT' and direction != 'RIGHT':
            direction = 'LEFT'
        if change_to == 'RIGHT' and direction != 'LEFT':
            direction = 'RIGHT'

        # snake movement
        if direction == 'UP':
            snake_pos[1] -= snake_speed
        if direction == 'DOWN':
            snake_pos[1] += snake_speed
        if direction == 'LEFT':
            snake_pos[0] -= snake_speed
        if direction == 'RIGHT':
            snake_pos[0] += snake_speed

        #snake body
        snake_body.insert(0, list(snake_pos))
        if snake_pos[0] == food_pos[0] and snake_pos[1] == food_pos[1]:
            score += 1
            sound.play()
            food_spawn = False
        else:
            snake_body.pop()

        if not food_spawn:
            food_pos = [random.randrange(1, (frame_size_x//25)) * 25, random.randrange(1, (frame_size_y//25)) * 25]
        food_spawn = True

        screen.blit(grass,(0,0))
        for pos in snake_body:
            pygame.draw.rect(screen, red, pygame.Rect(pos[0], pos[1], 25, 25), 4)
            
        food_rect = pygame.Rect(food_pos[0], food_pos[1], 25, 25)
        screen.blit(burger1, food_rect)

        
        #snake death
        if snake_pos[0] < 0 or snake_pos[0] > frame_size_x-25:
            life = 0
            snake_speed = 0 
            screen.blit(gameoverimg,(0,0))
            screen.blit(user_surface, (350,350))
            show_score(0, white, 25)
        
        if snake_pos[1] < 0 or snake_pos[1] > frame_size_y-25:
            life = 0
            snake_speed = 0
            screen.fill(black)
            screen.blit(gameoverimg,(0,0))
            screen.blit(user_surface, (350,350))
            show_score(0, white, 25)
            
            
        for block in snake_body[1:]:
            if snake_pos[0] == block[0] and snake_pos[1] == block[1]:
                life = 0
                snake_speed = 0 
                screen.blit(gameoverimg,(0,0))
                screen.blit(user_surface, (350,350))
                show_score(0, white, 25)
             
        user_surface = base_font.render(userinfo,  True, (255, 255, 255))
        show_score(1, white, 25)
        pygame.display.update() 
        fps_controller.tick(12)
    
