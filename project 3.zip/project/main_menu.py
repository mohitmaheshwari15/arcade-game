import pygame,sys
import random
from pygame import mixer
from mytestgame import pong
from arrowusingpygame import arrow
from escapegame import escape
from snakegame import snake
from leaderboardcode import leaderboard
pygame.init()
screen=pygame.display.set_mode((800,600))
icon=pygame.image.load("arcade.png")
pygame.display.set_icon(icon)
mixer.music.load("arcadebackground.wav")
mixer.music.play(-1)
buttonsound=mixer.Sound("buttonsound.mp3")
buttonsound.set_volume(0.5)

def mainmenu():
    image=pygame.image.load("arrowtext.png")
    image2=pygame.image.load("pongtext.png")
    image3=pygame.image.load("Escapetext.png")
    image4=pygame.image.load("spaceinvaderstext.png")
    image5=pygame.image.load('snaketext.png')
    image6=pygame.image.load('leaderboardtext.png')
    imageold=image
    image2old=image2
    image3old=image3
    image4old=image4
    image5old=image5
    image6old=image6
    background=pygame.image.load("arcadebackground.png")
    #textfont=pygame.font.Font("arial.ttf",48)
    textfont1=pygame.font.Font("freesansbold.ttf",24)
    pygame.display.set_caption("Main Menu")
    click=False
    while True:
        screen.fill((0,0,0))
        screen.blit(background,(0,0))
        mx,my=pygame.mouse.get_pos()
        click=False
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                sys.exit

            if event.type==pygame.MOUSEBUTTONDOWN:
                if event.button==1:
                    click=True

        button1=pygame.Rect(50,200,200,50)
        button2=pygame.Rect(50,300,200,50)
        button3=pygame.Rect(300,200,200,50)
        button4=pygame.Rect(300,300,200,50)
        button5=pygame.Rect(530,200,200,50)
        button6=pygame.Rect(530,300,200,50) 

        if button1.collidepoint((mx,my)):
            imagenew = pygame.transform.scale(image, (210, 60))
            image=imagenew
            if click:
                buttonsound.play()
                arrow()

        if button2.collidepoint((mx,my)):
            image2new = pygame.transform.scale(image2, (210, 60))
            image2=image2new

            if click:
                buttonsound.play()
                pong()
        if button3.collidepoint((mx,my)):
            image3new=pygame.transform.scale(image3,(210,60))
            image3=image3new

            if click:
                buttonsound.play()
                escape()

        if button4.collidepoint((mx,my)):
            image4new=pygame.transform.scale(image4,(210,60))
            image4=image4new
            if click:
                buttonsound.play()
                import spaceinvadergame

        if button5.collidepoint((mx,my)):
            image5new=pygame.transform.scale(image5,(210,60))
            image5=image5new
            if click:
                buttonsound.play()
                snake()

        if button6.collidepoint((mx,my)):
            image6new=pygame.transform.scale(image6,(210,60))
            image6=image6new
            if click:
                buttonsound.play()
                leaderboard()        
                
        screen.blit(image, button1)
        screen.blit(image2, button2)
        screen.blit(image3, button3)
        screen.blit(image4,button4)
        screen.blit(image5,button5)
        screen.blit(image6,button6)
        image=imageold
        image2=image2old
        image3=image3old
        image4=image4old
        image5=image5old
        image6=image6old
        #pygame.draw.rect(screen,(255,255,255),button1)
        #pygame.draw.rect(screen,(255,255,255),button2)

        
        pygame.display.update()
mainmenu()
