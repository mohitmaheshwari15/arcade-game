import pygame,sys
import random
import math
#import mysql.connector


'''
con=mysql.connector.connect(host='localhost',user='root',passwd='sohamkukreti',database='arcade')
cur=con.cursor() 
'''

pygame.init()

gamestate=''
userinfo=''
screen=pygame.display.set_mode((800,600))
base_font = pygame.font.Font(None,62)
pygame.display.set_caption("SPACE INVADERS!!!")
icon=pygame.image.load("rocket-ship (2).png")
pygame.display.set_icon(icon)
background=pygame.image.load("spacebg31.png")
pygame.mixer.music.load('space.wav')
pygame.mixer.music.play(-1)
rocket = pygame.image.load("spaceship11.png")
playerX = 380
playerY = 500
clock=pygame.time.Clock()
playerX_change=0

enemyF=[]
enemyX=[]
enemyY=[]
enemyX_change=[]
enemyY_change=[]
num_of_enemies=6

for i in range(num_of_enemies):
    enemyF.append(pygame.image.load("space-invaders (1).png"))
    enemyX.append(random.randint(10,770))
    enemyY.append(random.randint(50,150))
    enemyX_change.append(5)
    enemyY_change.append(30)

bulletIMG=pygame.image.load("bullet (1).png")
bulletX=0
bulletY=480
bulletX_change=0
bulletY_change=10
bullet_state="ready"
score_value=0
font=pygame.font.Font("freesansbold.ttf",38)

textX=10
textY=10

def show_score(x,y):
    score=font.render("Score: "+str(score_value),True,(255,0,0))
    screen.blit(score,(x,y))

def game_over_text(x,y):
    over_text=over_font.render("GAME OVER",True,(255,0,0))
    screen.blit(over_text,(x,y))

def player(x,y):
    screen.blit(rocket,(x,y))

def enemy(x,y,i):
    screen.blit(enemyF[i],(x,y))

def fire_bullet(x,y):
    global bullet_state
    bullet_state="fire"
    screen.blit(bulletIMG,(x+16,y+10))

def isCollision(enemyX,enemyY,bulletX,bulletY):
    distance=math.sqrt((math.pow(enemyX-bulletX,2))+(math.pow(enemyY-bulletY,2)))
    if distance<27:
        return True
    else:
        return False
running=True    
while running:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_LEFT:
                playerX_change=-10
            if event.key==pygame.K_RIGHT:
                playerX_change=10
            if event.key==pygame.K_ESCAPE:
                running=False
                pygame.mixer.music.load('arcadebackground.wav')
                pygame.mixer.music.play(-1)
        if event.type==pygame.KEYUP:
            if event.key==pygame.K_LEFT:
                playerX_change=0
            if event.key==pygame.K_RIGHT:
                playerX_change=0
            if event.key==pygame.K_SPACE:
                    bulletX=playerX
                    fire_bullet(bulletX,bulletY)
                    
        if event.type==pygame.KEYDOWN:
            
            if event.key==pygame.K_RETURN:
                if gamestate=="over":
                    '''
                    cur.execute('insert into space values("{}", {})'.format(userinfo,score_value))
                    con.commit()
                    '''
                    print(userinfo,":",score_value)
                    running=False
                    pygame.quit()
                    sys.exit()
            if gamestate=='over':
                userinfo+=event.unicode
                if event.key==pygame.K_BACKSPACE:
                    userinfo=userinfo[0:-2]
             
            
                    
    
    screen.fill((0,0,0))
    text_surface = base_font.render(userinfo,True,(0,255,255))
    
    
    screen.blit(background,(0,0))

    if playerX<=0:
        playerX=0
    elif playerX>=770:
        playerX=770

    for i in range(num_of_enemies):
        
        if enemyY[i]>440:
            gamestate="over"
            
            for j in range(num_of_enemies):
                enemyY[j]=2000 
                screen.blit(pygame.image.load('gameover1.png'),(0,0))

            break
    
        
        enemyX[i]+=enemyX_change[i]
        if enemyX[i]<=0:
            enemyX_change[i]=5
            enemyY[i]+=enemyY_change[i]
        elif enemyX[i]>=770:
            enemyX_change[i]=-5
            enemyY[i]-=enemyX_change[i]
            
        collision=isCollision(enemyX[i],enemyY[i],bulletX,bulletY)
        if collision:
            bulletY=480
            bullet_state="ready"
            score_value+=1
    
            enemyX[i]=random.randint(10,780)
            enemyY[i]=random.randint(50,150)

        enemy(enemyX[i],enemyY[i],i)

    if bulletY<=0:
        bulletY=480
        bullet_state="ready"                                

    if bullet_state == "fire":
        fire_bullet(bulletX,bulletY)
        bulletY-=bulletY_change
    if gamestate=="over":
        screen.blit(text_surface,(250,300))
    
    enemyX+=enemyX_change
    playerX+=playerX_change
    show_score(textX,textY)
    player(playerX,playerY)
    clock.tick(60)
    pygame.display.update()
    


